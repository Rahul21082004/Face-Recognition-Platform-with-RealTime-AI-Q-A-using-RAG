import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import mongoose from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

// Initialize Express app
const app = express();
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Create HTTP server
const server = createServer(app);

// Initialize Socket.IO
const io = new Server(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});

// Connect to MongoDB (replace with your connection string)
mongoose.connect('mongodb://localhost:27017/face-recognition', {})
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Define Face Schema
const faceSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  descriptor: {
    type: [Number],
    required: true
  },
  imageData: {
    type: String,
    required: true
  },
  registeredAt: {
    type: Date,
    default: Date.now
  }
});

const Face = mongoose.model('Face', faceSchema);

// Helper for face recognition
function cosineSimilarity(a, b) {
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  
  normA = Math.sqrt(normA);
  normB = Math.sqrt(normB);
  
  if (normA === 0 || normB === 0) {
    return 0;
  }
  
  return dotProduct / (normA * normB);
}

function findBestMatch(descriptor, faceDescriptors, threshold = 0.6) {
  let bestMatch = null;
  let bestScore = -1;
  
  for (const face of faceDescriptors) {
    const similarity = cosineSimilarity(descriptor, face.descriptor);
    
    if (similarity > threshold && similarity > bestScore) {
      bestScore = similarity;
      bestMatch = face;
    }
  }
  
  return bestMatch;
}

// Mock RAG functionality (to be replaced with actual implementation)
async function processRagQuery(question) {
  // In a real implementation, this would:
  // 1. Convert the question to an embedding
  // 2. Find similar documents in the vector store
  // 3. Use LLM to generate an answer based on retrieved documents
  
  // For demo purposes, we'll use simple pattern matching
  const questionLower = question.toLowerCase();
  
  try {
    // Get data from the database to answer the query
    if (questionLower.includes('last person registered')) {
      const lastRegistered = await Face.findOne().sort({ registeredAt: -1 });
      if (lastRegistered) {
        return `The last person registered was ${lastRegistered.name} at ${new Date(lastRegistered.registeredAt).toLocaleString()}.`;
      }
      return 'No one has been registered yet.';
    }
    
    if (questionLower.includes('how many')) {
      const count = await Face.countDocuments();
      return `There are currently ${count} ${count === 1 ? 'person' : 'people'} registered in the system.`;
    }
    
    if (questionLower.includes('when was') || questionLower.includes('at what time')) {
      // Extract name
      const nameMatch = questionLower.match(/when was ([a-z ]+) registered|at what time was ([a-z ]+) registered/);
      let name = null;
      
      if (nameMatch) {
        name = nameMatch[1] || nameMatch[2];
        
        const person = await Face.findOne({ 
          name: { $regex: new RegExp(name, 'i') }
        });
        
        if (person) {
          return `${person.name} was registered on ${new Date(person.registeredAt).toLocaleString()}.`;
        }
        
        return `I couldn't find anyone named "${name}" in the registration database.`;
      }
    }
    
    // Default response
    return "I'm not sure how to answer that question. You can ask me about who was registered, when someone was registered, or how many people are registered.";
  } catch (error) {
    console.error('Error processing RAG query:', error);
    return "I encountered an error while trying to answer your question. Please try again.";
  }
}

// Socket.IO connection handler
io.on('connection', (socket) => {
  console.log('A user connected');
  
  // Handle face registration
  socket.on('register-face', async (data, callback) => {
    try {
      const { name, descriptor, imageData } = data;
      
      // Save to database
      const newFace = new Face({
        name,
        descriptor,
        imageData,
        registeredAt: new Date()
      });
      
      await newFace.save();
      
      callback({ success: true });
    } catch (error) {
      console.error('Registration error:', error);
      callback({ success: false, error: error.message });
    }
  });
  
  // Handle face recognition
  socket.on('recognize-faces', async (data, callback) => {
    try {
      const { descriptors } = data;
      
      // Get all faces from database
      const allFaces = await Face.find({});
      
      // Match each descriptor
      const recognizedFaces = descriptors.map(descriptor => {
        const match = findBestMatch(descriptor, allFaces);
        
        if (match) {
          return {
            name: match.name,
            // In a real implementation, we'd calculate the box here
            // but for our demo we'll rely on the frontend detection
            box: { x: 0, y: 0, width: 0, height: 0 }
          };
        }
        
        return {
          name: 'Unknown',
          box: { x: 0, y: 0, width: 0, height: 0 }
        };
      });
      
      callback({ success: true, faces: recognizedFaces });
    } catch (error) {
      console.error('Recognition error:', error);
      callback({ success: false, error: error.message });
    }
  });
  
  // Handle chat messages for RAG
  socket.on('chat-message', async (data) => {
    try {
      const { text } = data;
      
      // Process query through RAG
      const response = await processRagQuery(text);
      
      // Send back response
      socket.emit('chat-response', { text: response });
    } catch (error) {
      console.error('Chat error:', error);
      socket.emit('chat-response', { 
        text: 'Sorry, I encountered an error processing your question. Please try again.' 
      });
    }
  });
  
  socket.on('disconnect', () => {
    console.log('A user disconnected');
  });
});

// Start server
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});