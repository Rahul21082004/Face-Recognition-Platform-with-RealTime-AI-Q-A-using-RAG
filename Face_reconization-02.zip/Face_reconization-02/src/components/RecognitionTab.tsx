import React, { useRef, useState, useEffect, useCallback } from 'react';
import Webcam from 'react-webcam';
import { Camera, AlertCircle, RefreshCw } from 'lucide-react';

interface FaceRecognitionResult {
  name: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  id?: string;
  timestamp?: string;
}

interface ApiResponse {
  success: boolean;
  faces: FaceRecognitionResult[];
  message?: string;
  error?: string;
}

interface LiveRecognitionTabProps {
  apiEndpoint?: string;
}

const LiveRecognitionTab: React.FC<LiveRecognitionTabProps> = ({
  apiEndpoint = 'http://127.0.0.1:5000/api/recognize'
}) => {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [isCameraError, setIsCameraError] = useState<string | null>(null);
  const [recognizedFaces, setRecognizedFaces] = useState<FaceRecognitionResult[]>([]);
  const [message, setMessage] = useState({ text: '', type: '' });
  const [isProcessing, setIsProcessing] = useState(false);

  const videoConstraints = {
    width: { ideal: 640 },
    height: { ideal: 480 },
    facingMode: 'user'
  };

  // Check camera permissions and initialize
  useEffect(() => {
    const checkCameraPermissions = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach(track => track.stop());
        setIsCameraReady(true);
      } catch (error) {
        console.error('Camera access error:', error);
        setIsCameraError('Camera access denied. Please allow camera permissions in your browser.');
      }
    };
    checkCameraPermissions();

    return () => {
      if (webcamRef.current?.video?.srcObject) {
        const stream = webcamRef.current.video.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Convert base64 to File for FormData
  const base64ToFile = (base64: string, filename: string): File => {
    const [header, data] = base64.split(',');
    const mime = header.match(/:(.*?);/)?.[1] || 'image/jpeg';
    const byteString = atob(data);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const uint8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      uint8Array[i] = byteString.charCodeAt(i);
    }
    return new File([arrayBuffer], filename, { type: mime });
  };

  // Recognize faces via REST API
  const recognizeFacesAPI = async (image: string): Promise<ApiResponse> => {
    try {
      const formData = new FormData();
      const imageFile = base64ToFile(image, 'frame-capture.jpg');
      formData.append('image', imageFile);

      const response = await fetch(apiEndpoint, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server error (${response.status}): ${errorText}`);
      }

      const data: ApiResponse = await response.json();
      return data;
    } catch (error) {
      console.error('API Recognition error:', error);
      throw error;
    }
  };

  // Draw bounding boxes and names on canvas
  const drawBoundingBoxes = useCallback((faces: FaceRecognitionResult[]) => {
    if (!canvasRef.current || !webcamRef.current?.video) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const video = webcamRef.current.video;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    faces.forEach(face => {
      const { x, y, width, height } = face.bbox;
      const confidence = (face.confidence * 100).toFixed(1);

      // Draw bounding box
      ctx.strokeStyle = 'rgba(0, 255, 0, 0.8)';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, height);

      // Draw name and confidence label
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(x, y - 30, width, 30);
      ctx.font = '14px Arial';
      ctx.fillStyle = 'white';
      ctx.fillText(`${face.name} (${confidence}%)`, x + 5, y - 10);
    });
  }, []);

  // Process frames for face recognition (1-2 frames per second)
  const processFrame = useCallback(async () => {
    if (!webcamRef.current || isProcessing || !isCameraReady) return;

    setIsProcessing(true);
    try {
      const imageSrc = webcamRef.current.getScreenshot({ width: 640, height: 480 });
      if (imageSrc) {
        const result = await recognizeFacesAPI(imageSrc);
        if (result.success && result.faces) {
          setRecognizedFaces(result.faces);
          drawBoundingBoxes(result.faces);
          setMessage({
            text: result.faces.length > 0 
              ? `Detected ${result.faces.length} face${result.faces.length > 1 ? 's' : ''}`
              : 'No faces detected',
            type: result.faces.length > 0 ? 'success' : 'info'
          });
        } else {
          setRecognizedFaces([]);
          drawBoundingBoxes([]);
          setMessage({ text: result.error || 'No faces recognized', type: 'error' });
        }
      }
    } catch (error: any) {
      setMessage({ text: `Recognition error: ${error.message}`, type: 'error' });
      setRecognizedFaces([]);
      drawBoundingBoxes([]);
    } finally {
      setIsProcessing(false);
    }
  }, [isProcessing, isCameraReady, drawBoundingBoxes]);

  // Process frames at 1-2 FPS
  useEffect(() => {
    const interval = setInterval(() => {
      if (isCameraReady && !isCameraError) {
        processFrame();
      }
    }, 500); // 2 FPS (adjust to 1000 for 1 FPS if needed)

    return () => clearInterval(interval);
  }, [isCameraReady, isCameraError, processFrame]);

  // Retry camera initialization
  const retryCamera = () => {
    setIsCameraError(null);
    if (webcamRef.current?.video?.srcObject) {
      const stream = webcamRef.current.video.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setIsCameraReady(false);
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        stream.getTracks().forEach(track => track.stop());
        setIsCameraReady(true);
      })
      .catch(error => {
        setIsCameraError('Camera access denied. Please allow camera permissions.');
      });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">Live Face Recognition</h2>
            <p className="text-slate-400">Real-time face detection and recognition</p>
          </div>
          <div className="text-sm text-slate-400">REST API Mode</div>
        </div>
      </div>

      <div className="card">
        <h3 className="text-xl font-semibold mb-4">Live Video Feed</h3>

        <div className="relative overflow-hidden rounded-lg bg-slate-900 aspect-video mb-4">
          {isCameraError ? (
            <div className="flex flex-col items-center justify-center h-full bg-slate-800 text-slate-300">
              <AlertCircle size={24} className="text-red-500 mb-2" />
              <p className="text-sm text-center">{isCameraError}</p>
              <button
                className="mt-4 btn btn-outline"
                onClick={retryCamera}
              >
                <RefreshCw size={18} />
                Retry Camera
              </button>
            </div>
          ) : (
            <>
              <Webcam
                audio={false}
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                videoConstraints={videoConstraints}
                className="w-full h-auto"
                onUserMedia={() => setIsCameraReady(true)}
                onUserMediaError={(error) => {
                  setIsCameraError('Camera initialization failed. Please check your camera and permissions.');
                  console.error('Webcam error:', error);
                }}
              />
              <canvas
                ref={canvasRef}
                className="absolute top-0 left-0 w-full h-full"
                style={{ pointerEvents: 'none' }}
              />
              {isCameraReady && (
                <div className="absolute bottom-4 left-4 bg-green-900 bg-opacity-75 text-green-200 text-sm py-1 px-3 rounded-full">
                  Camera Ready
                </div>
              )}
            </>
          )}
        </div>

        {message.text && (
          <div className={`mt-4 p-3 rounded flex items-center ${
            message.type === 'success' ? 'bg-green-900 text-green-200' :
            message.type === 'error' ? 'bg-red-900 text-red-200' :
            'bg-blue-900 text-blue-200'
          }`}>
            {message.type === 'error' && <AlertCircle size={16} className="mr-2" />}
            {message.text}
          </div>
        )}

        {recognizedFaces.length > 0 && (
          <div className="mt-6">
            <h4 className="font-medium text-sm text-slate-400 mb-2">Recognized Faces:</h4>
            <div className="grid grid-cols-1 gap-4">
              {recognizedFaces.map((face, index) => (
                <div key={index} className="bg-slate-900 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Camera size={14} className="mr-2 text-blue-400" />
                      <span className="text-white font-medium">{face.name}</span>
                    </div>
                    <span className="text-sm text-slate-400">
                      Confidence: {(face.confidence * 100).toFixed(1)}%
                    </span>
                  </div>
                  {face.id && (
                    <div className="mt-2 text-sm text-slate-400">
                      ID: {face.id}
                    </div>
                  )}
                  {face.timestamp && (
                    <div className="mt-1 text-sm text-slate-400">
                      Detected: {new Date(face.timestamp).toLocaleString()}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-6">
          <h4 className="font-medium text-sm text-slate-400 mb-2">Recognition Details:</h4>
          <ul className="text-sm text-slate-400 list-disc pl-5 space-y-1">
            <li>Processes 1-2 frames per second</li>
            <li>Matches against stored face encodings in MongoDB</li>
            <li>Displays bounding boxes and names for recognized faces</li>
            <li>Supports multiple face recognition in a single frame</li>
            <li>Requires good lighting and clear frontal view</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default LiveRecognitionTab;