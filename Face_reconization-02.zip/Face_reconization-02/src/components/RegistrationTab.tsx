import React, { useRef, useState, useEffect, useCallback } from 'react';
import Webcam from 'react-webcam';
import { Camera, Check, Save, AlertCircle, CheckCircle, X, User, Calendar, Clock, RefreshCw, Upload } from 'lucide-react';

interface RegistrationData {
  name: string;
  image: File | Blob;
}

interface ApiResponse {
  success: boolean;
  message?: string;
  error?: string;
  id?: string;
  timestamp?: string;
}

interface RegistrationTabProps {
  apiEndpoint?: string;
  fileUploadEndpoint?: string;
}

const RegistrationTab: React.FC<RegistrationTabProps> = ({
  apiEndpoint = 'http://127.0.0.1:5000/api/register',
  fileUploadEndpoint = 'http://127.0.0.1:5000/api/register/file'
}) => {
  const webcamRef = useRef<Webcam>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [name, setName] = useState('');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [isCameraError, setIsCameraError] = useState<string | null>(null);
  const [isRegistering, setIsRegistering] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [registrationResult, setRegistrationResult] = useState<any>(null);
  const [useFileUpload, setUseFileUpload] = useState(false);

  const videoConstraints = {
    width: { ideal: 640 },
    height: { ideal: 480 },
    facingMode: 'user'
  };

  // Check camera permissions and initialize
  useEffect(() => {
    const checkCameraPermissions = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach(track => track.stop());
        setIsCameraReady(true);
      } catch (error) {
        console.error('Camera access error:', error);
        setIsCameraError('Camera access denied. Please allow camera permissions or use file upload.');
        setUseFileUpload(true);
      }
    };
    checkCameraPermissions();

    return () => {
      if (webcamRef.current?.video?.srcObject) {
        const stream = webcamRef.current.video.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Capture image from webcam
  const captureImage = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot({ width: 640, height: 480 });
      if (imageSrc) {
        setCapturedImage(imageSrc);
        setMessage({ text: 'Image captured. Verifying face...', type: 'info' });
      } else {
        setMessage({ text: 'Failed to capture image. Please try again.', type: 'error' });
      }
    }
  }, []);

  // Handle file upload
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const allowedTypes = ['image/jpeg', 'image/png'];
      if (!allowedTypes.includes(file.type)) {
        setMessage({ text: 'Please upload a JPEG or PNG image.', type: 'error' });
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        setMessage({ text: 'Image size exceeds 5MB limit.', type: 'error' });
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setCapturedImage(reader.result as string);
        setMessage({ text: 'Image uploaded. Verifying face...', type: 'info' });
      };
      reader.readAsDataURL(file);
    }
  };

  // Reset capture state
  const resetCapture = () => {
    setCapturedImage(null);
    setMessage({ text: '', type: '' });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Reset entire form
  const resetForm = () => {
    setName('');
    setCapturedImage(null);
    setMessage({ text: '', type: '' });
    setRegistrationResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Convert base64 to File for FormData
  const base64ToFile = (base64: string, filename: string): File => {
    const [header, data] = base64.split(',');
    const mime = header.match(/:(.*?);/)?.[1] || 'image/jpeg';
    const byteString = atob(data);
    const arrayBuffer = new ArrayBuffer(byteString.length);
    const uint8Array = new Uint8Array(arrayBuffer);
    for (let i = 0; i < byteString.length; i++) {
      uint8Array[i] = byteString.charCodeAt(i);
    }
    return new File([arrayBuffer], filename, { type: mime });
  };

  // Register face via REST API
  const registerFaceAPI = async (registrationData: RegistrationData): Promise<ApiResponse> => {
    try {
      const formData = new FormData();
      formData.append('name', registrationData.name);
      formData.append('image', registrationData.image, 'face-capture.jpg');

      const response = await fetch(useFileUpload ? fileUploadEndpoint : apiEndpoint, {
        method: 'POST',
        body: formData,
        signal: AbortSignal.timeout(10000), // 10-second timeout
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server error (${response.status}): ${errorText}`);
      }

      const data: ApiResponse = await response.json();
      return data;
    } catch (error: any) {
      if (error.name === 'TimeoutError') {
        throw new Error('Request timed out. Please try again.');
      }
      console.error('API Registration error:', error);
      throw error;
    }
  };

  // Handle registration
  const handleRegister = async () => {
    if (!capturedImage || !name.trim()) {
      setMessage({ text: 'Please provide a name and capture or upload an image.', type: 'error' });
      return;
    }

    setIsRegistering(true);
    setMessage({ text: 'Processing registration...', type: 'info' });

    try {
      const now = new Date();
      const imageFile = base64ToFile(capturedImage, 'face-capture.jpg');
      const registrationData: RegistrationData = {
        name: name.trim(),
        image: imageFile,
      };

      const result = await registerFaceAPI(registrationData);

      if (result.success) {
        setRegistrationResult({
          name: registrationData.name,
          date: now.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
          day: now.toLocaleDateString('en-US', { weekday: 'long' }),
          time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          id: result.id,
          timestamp: result.timestamp
        });
        setShowSuccessPopup(true);
        setMessage({ text: '', type: '' });
      } else {
        throw new Error(result.error || 'Registration failed');
      }
    } catch (error: any) {
      let errorMessage = error.message.includes('Exactly one face') ? 
        'Please capture or upload an image with exactly one face.' :
        error.message.includes('already exists') ? 
        `The name "${name}" is already registered. Please use a unique name.` :
        error.message.includes('Unsupported image format') ?
        'Please use a JPEG or PNG image.' :
        error.message.includes('Image size exceeds') ?
        'Image size exceeds 5MB limit.' :
        `Registration failed: ${error.message}`;
      setMessage({ text: errorMessage, type: 'error' });
    } finally {
      setIsRegistering(false);
    }
  };

  // Close success popup
  const closeSuccessPopup = () => {
    setShowSuccessPopup(false);
    setTimeout(() => resetForm(), 300);
  };

  // Retry camera initialization
  const retryCamera = () => {
    setIsCameraError(null);
    if (webcamRef.current?.video?.srcObject) {
      const stream = webcamRef.current.video.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setIsCameraReady(false);
    navigator.mediaDevices.getUserMedia({ video: true })
      .then(stream => {
        stream.getTracks().forEach(track => track.stop());
        setIsCameraReady(true);
        setUseFileUpload(false);
      })
      .catch(error => {
        setIsCameraError('Camera access denied. Please allow camera permissions or use file upload.');
        setUseFileUpload(true);
      });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2">Face Registration</h2>
            <p className="text-slate-400">Capture or upload a face image with a unique name</p>
          </div>
          <div className="text-sm text-slate-400">REST API Mode</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Capture Face</h3>

          <div className="relative overflow-hidden rounded-lg bg-slate-900 aspect-video mb-4">
            {isCameraError && !capturedImage ? (
              <div className="flex flex-col items-center justify-center h-full bg-slate-800 text-slate-300">
                <AlertCircle size={24} className="text-red-500 mb-2" />
                <p className="text-sm text-center">{isCameraError}</p>
                <button
                  className="mt-4 btn btn-outline"
                  onClick={retryCamera}
                >
                  <RefreshCw size={18} />
                  Retry Camera
                </button>
                <button
                  className="mt-2 btn btn-outline"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload size={18} />
                  Upload Image
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/jpeg,image/png"
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </div>
            ) : !capturedImage ? (
              <>
                <Webcam
                  audio={false}
                  ref={webcamRef}
                  screenshotFormat="image/jpeg"
                  videoConstraints={videoConstraints}
                  className="w-full h-auto"
                  onUserMedia={() => setIsCameraReady(true)}
                  onUserMediaError={(error) => {
                    setIsCameraError('Camera initialization failed. Please check your camera and permissions or use file upload.');
                    setUseFileUpload(true);
                    console.error('Webcam error:', error);
                  }}
                />
                {isCameraReady && (
                  <div className="absolute bottom-4 left-4 bg-green-900 bg-opacity-75 text-green-200 text-sm py-1 px-3 rounded-full">
                    Camera Ready
                  </div>
                )}
              </>
            ) : (
              <img
                src={capturedImage}
                alt="Captured face"
                className="w-full h-auto"
              />
            )}
          </div>

          <div className="flex justify-center space-x-4">
            {!capturedImage ? (
              <>
                <button
                  className="btn btn-primary"
                  onClick={captureImage}
                  disabled={!isCameraReady || isCameraError !== null}
                >
                  <Camera size={18} />
                  Capture Photo
                </button>
                <button
                  className="btn btn-outline"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload size={18} />
                  Upload Image
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/jpeg,image/png"
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </>
            ) : (
              <>
                <button
                  className="btn btn-outline"
                  onClick={resetCapture}
                  disabled={isRegistering}
                >
                  Retake/Upload New
                </button>
                <div className="flex items-center text-yellow-500">
                  <AlertCircle size={18} className="mr-1" />
                  Face verification pending
                </div>
              </>
            )}
          </div>
        </div>

        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Registration Details</h3>

          <div className="mb-4">
            <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-2">
              Full Name *
            </label>
            <input
              type="text"
              id="name"
              className="input w-full"
              placeholder="Enter full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={isRegistering}
            />
          </div>

          <div className="mb-6 p-3 bg-slate-900 rounded-lg">
            <h4 className="text-sm font-medium text-slate-400 mb-2">Registration Details</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="flex items-center text-slate-300">
                <Calendar size={14} className="mr-1" />
                {new Date().toLocaleDateString('en-US', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
              <div className="flex items-center text-slate-300">
                <Clock size={14} className="mr-1" />
                {new Date().toLocaleTimeString('en-US', {
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </div>
            </div>
          </div>

          <button
            className="btn btn-primary w-full"
            disabled={!capturedImage || !name.trim() || isRegistering}
            onClick={handleRegister}
          >
            {isRegistering ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </div>
            ) : (
              <>
                <Save size={18} />
                Register Face
              </>
            )}
          </button>

          {message.text && (
            <div className={`mt-4 p-3 rounded flex items-center ${
              message.type === 'success' ? 'bg-green-900 text-green-200' :
              message.type === 'error' ? 'bg-red-900 text-red-200' :
              'bg-blue-900 text-blue-200'
            }`}>
              {message.type === 'error' && <AlertCircle size={16} className="mr-2" />}
              {message.text}
            </div>
          )}

          <div className="mt-6">
            <h4 className="font-medium text-sm text-slate-400 mb-2">Requirements:</h4>
            <ul className="text-sm text-slate-400 list-disc pl-5 space-y-1">
              <li>Clear frontal view of face</li>
              <li>Good lighting conditions</li>
              <li>Unique name for each person</li>
              <li>Hold still during capture</li>
              <li>Ensure face fills most of the frame</li>
              <li>Use JPEG or PNG format (max 5MB)</li>
            </ul>
          </div>
        </div>
      </div>

      {showSuccessPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-lg p-6 max-w-md w-full mx-4 relative animate-in zoom-in-95 duration-200">
            <button
              onClick={closeSuccessPopup}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200"
            >
              <X size={20} />
            </button>

            <div className="text-center">
              <div className="mb-4">
                <CheckCircle size={48} className="text-green-500 mx-auto" />
              </div>

              <h3 className="text-xl font-bold text-green-400 mb-2">
                Registration Successful!
              </h3>

              <p className="text-slate-300 mb-4">
                Face has been successfully registered and stored in MongoDB.
              </p>

              {registrationResult && (
                <div className="bg-slate-900 rounded-lg p-4 text-left">
                  <h4 className="font-semibold mb-3 text-slate-200">Registration Details:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center">
                      <User size={14} className="mr-2 text-blue-400" />
                      <span className="text-slate-400">Name:</span>
                      <span className="ml-2 text-white font-medium">{registrationResult.name}</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar size={14} className="mr-2 text-blue-400" />
                      <span className="text-slate-400">Date:</span>
                      <span className="ml-2 text-white">{registrationResult.date}</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar size={14} className="mr-2 text-blue-400" />
                      <span className="text-slate-400">Day:</span>
                      <span className="ml-2 text-white">{registrationResult.day}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock size={14} className="mr-2 text-blue-400" />
                      <span className="text-slate-400">Time:</span>
                      <span className="ml-2 text-white">{registrationResult.time}</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle size={14} className="mr-2 text-blue-400" />
                      <span className="text-slate-400">ID:</span>
                      <span className="ml-2 text-white">{registrationResult.id}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={closeSuccessPopup}
                  className="btn btn-primary flex-1"
                >
                  Register Another Face
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RegistrationTab;