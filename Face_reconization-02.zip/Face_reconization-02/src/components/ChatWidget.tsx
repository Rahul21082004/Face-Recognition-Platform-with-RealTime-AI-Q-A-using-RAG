import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Send, X, User, BrainCircuit, AlertCircle, Wifi, WifiOff, RefreshCw, Database } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  error?: boolean;
  loading?: boolean;
  type?: 'system' | 'normal';
}

interface ApiResponse {
  success: boolean;
  data?: any;
  message?: string;
  error?: string;
  response?: string;
  timestamp?: string;
}

interface ChatWidgetProps {
  onClose: () => void;
  flaskEndpoint?: string;
  maxRetries?: number;
  retryDelay?: number;
}

const ChatWidget: React.FC<ChatWidgetProps> = ({
  onClose,
  flaskEndpoint = 'http://127.0.0.1:5000/api/query',
  maxRetries = 3,
  retryDelay = 1000,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: `📊 Hello! I'm your intelligent AI assistant for your face registration database:\n\n` +
            `You can ask:\n• "Who was registered today?"\n• "How many people are registered?"\n• "Show me the latest registrations"\n• "When was [name] registered?"\n• "Find users registered this week"`,
      sender: 'ai',
      timestamp: new Date(),
      type: 'system',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isConnected, setIsConnected] = useState(true);
  const [retryCount, setRetryCount] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Test connection on mount
  useEffect(() => {
    testFlaskConnection();
  }, [flaskEndpoint]);

  // Test Flask backend connection
  const testFlaskConnection = useCallback(async () => {
    try {
      const healthEndpoint = flaskEndpoint.replace('/api/query', '/health');
      const response = await fetch(healthEndpoint, {
        method: 'GET',
        signal: AbortSignal.timeout(5000),
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setIsConnected(data.status === 'ok' || data.status === 'healthy');
        console.log('Flask connection test:', data);
      } else {
        setIsConnected(false);
        console.warn('Flask health check failed:', response.status);
      }
    } catch (error) {
      console.warn('Flask connection test failed:', error);
      setIsConnected(false);
    }
  }, [flaskEndpoint]);

  // Flask API query for RAG system
  const queryFlaskWithRetry = async (query: string, attempt: number = 1): Promise<string> => {
    try {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      abortControllerRef.current = new AbortController();

      const response = await fetch(flaskEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          query: query.trim(),
          timestamp: Date.now(),
          context: 'face_registration_data',
        }),
        signal: abortControllerRef.current.signal,
      });

      setIsConnected(true);
      setRetryCount(0);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Flask server error:', response.status, errorText);
        throw new Error(`Server error (${response.status}): ${errorText || 'Unknown error'}`);
      }

      const data: ApiResponse = await response.json();
      console.log('Flask response:', data);

      if (data.success) {
        return data.response || data.message || 'Query processed successfully.';
      }

      throw new Error(data.error || 'Query failed - no response from RAG system');
    } catch (error: any) {
      if (error.name === 'AbortError') {
        throw new Error('Request was cancelled');
      }

      // Handle connection errors with retry logic
      if (error.name === 'TypeError' || error.message.includes('fetch') || error.message.includes('Failed to fetch')) {
        setIsConnected(false);
        if (attempt < maxRetries) {
          setRetryCount(attempt);
          console.log(`Retrying Flask request (${attempt}/${maxRetries})...`);
          await new Promise(resolve => setTimeout(resolve, retryDelay * attempt));
          return queryFlaskWithRetry(query, attempt + 1);
        }
        throw new Error(
          `❌ Connection failed after ${maxRetries} attempts.\n\nPlease ensure:\n• Flask server is running on the correct port\n• RAG system is properly initialized\n• Network connectivity is stable`
        );
      }

      // Handle server errors with retry
      if (error.message.includes('Server error') && attempt < maxRetries) {
        setRetryCount(attempt);
        console.log(`Retrying server request (${attempt}/${maxRetries})...`);
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        return queryFlaskWithRetry(query, attempt + 1);
      }

      throw error;
    }
  };

  const handleSubmit = async () => {
    if (!input.trim() || isLoading) return;

    const currentInput = input.trim();
    setInput('');

    const userMessage: Message = {
      id: Date.now().toString(),
      text: currentInput,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    setRetryCount(0);

    try {
      const response = await queryFlaskWithRetry(currentInput);

      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          text: response,
          sender: 'ai',
          timestamp: new Date(),
        },
      ]);
    } catch (error: any) {
      console.error('Error sending message:', error);
      let errorMessage = 'Sorry, I encountered an error. Please try again.';

      if (error.message.includes('Connection failed')) {
        errorMessage = `${error.message}`;
      } else if (error.message.includes('cancelled')) {
        return; // Don't show error for cancelled requests
      } else if (error.message.includes('RAG system not initialized')) {
        errorMessage = `🔄 RAG system is initializing. Please wait a moment and try again.`;
        try {
          await fetch(flaskEndpoint.replace('/api/query', '/api/reinitialize'), { method: 'POST' });
        } catch (e) {
          console.warn('Failed to trigger reinitialization:', e);
        }
      } else {
        errorMessage = `❌ Error: ${error.message}`;
      }

      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          text: errorMessage,
          sender: 'ai',
          timestamp: new Date(),
          error: true,
        },
      ]);
    } finally {
      setIsLoading(false);
      setRetryCount(0);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleRetry = () => {
    if (messages.length > 1) {
      const lastUserMessage = [...messages].reverse().find(m => m.sender === 'user');
      if (lastUserMessage) {
        setInput(lastUserMessage.text);
      }
    }
    testFlaskConnection();
  };

  const clearChat = () => {
    setMessages([
      {
        id: Date.now().toString(),
        text: `🧹 Chat cleared! I'm ready to help you with your face registration database queries.`,
        sender: 'ai',
        timestamp: new Date(),
        type: 'system',
      },
    ]);
  };

  return (
    <div className="fixed bottom-4 right-4 w-80 sm:w-96 h-[600px] max-h-[85vh] bg-white dark:bg-gray-900 rounded-xl shadow-2xl flex flex-col z-50 overflow-hidden border border-gray-200 dark:border-gray-700">
      {/* Header */}
      <div className="p-4 flex justify-between items-center bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="flex items-center">
          <Database className="w-5 h-5 mr-2" />
          <div>
            <h3 className="font-bold text-sm">RAG Database AI</h3>
            <div className="flex items-center text-xs opacity-90">
              {isConnected ? (
                <>
                  <Wifi className="w-3 h-3 mr-1" />
                  <span>Connected</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3 h-3 mr-1" />
                  <span>Disconnected</span>
                </>
              )}
              {retryCount > 0 && (
                <span className="ml-2 text-yellow-200">
                  Retry {retryCount}/{maxRetries}
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={handleRetry}
            className="hover:bg-white/20 p-1 rounded transition-colors"
            title="Test Connection"
          >
            <RefreshCw size={16} />
          </button>
          <button
            onClick={onClose}
            className="hover:bg-white/20 p-1 rounded transition-colors"
            title="Close Chat"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto bg-gray-50 dark:bg-gray-850 space-y-3">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-3 ${
                message.sender === 'user'
                  ? 'bg-blue-600 text-white'
                  : message.error
                  ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800'
                  : message.type === 'system'
                  ? 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700'
                  : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 shadow-sm border border-gray-200 dark:border-gray-700'
              }`}
            >
              <div className="flex items-center mb-1">
                {message.sender === 'ai' ? (
                  message.error ? (
                    <AlertCircle size={14} className="mr-2 text-red-500" />
                  ) : message.type === 'system' ? (
                    <BrainCircuit size={14} className="mr-2 text-gray-500" />
                  ) : (
                    <Database size={14} className="mr-2 text-blue-500" />
                  )
                ) : (
                  <User size={14} className="mr-2" />
                )}
                <span className="text-xs font-medium opacity-75">
                  {message.sender === 'user' ? 'You' : message.error ? 'System' : message.type === 'system' ? 'Assistant' : 'RAG AI'}
                </span>
              </div>
              <p className="text-sm whitespace-pre-line leading-relaxed">{message.text}</p>
              <span className="text-xs opacity-60 block mt-2">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="max-w-[85%] rounded-2xl p-3 bg-white dark:bg-gray-800 shadow-sm border border-gray-200 dark:border-gray-700">
              <div className="flex items-center space-x-2">
                <Database size={14} className="text-blue-500" />
                <span className="text-xs opacity-75">Searching database...</span>
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
              {retryCount > 0 && (
                <div className="text-xs text-yellow-600 dark:text-yellow-400 mt-2">
                  Retrying... ({retryCount}/{maxRetries})
                </div>
              )}
            </div>
          </div>
        )}

        <div ref={messagesEndRef}></div>
      </div>

      {/* Input */}
      <div className="p-4 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700">
        <div className="flex space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={isConnected ? 'Query your database...' : 'Check connection first...'}
            className="flex-1 text-sm px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
            disabled={isLoading || !isConnected}
          />
          <button
            onClick={handleSubmit}
            className={`px-4 py-3 rounded-xl transition-all ${
              !input.trim() || isLoading || !isConnected
                ? 'bg-gray-300 dark:bg-gray-600 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-blue-500/25'
            }`}
            disabled={!input.trim() || isLoading || !isConnected}
          >
            <Send size={16} />
          </button>
        </div>
        <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
          {isConnected ? (
            <div>📊 Connected to RAG system - Query your face registration data</div>
          ) : (
            <div className="text-red-500 dark:text-red-400">
              ⚠️ RAG server disconnected. Click refresh to reconnect.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatWidget;