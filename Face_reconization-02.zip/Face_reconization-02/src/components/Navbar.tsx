import React from 'react';
import { ScanFace, UserPlus } from 'lucide-react';

interface NavbarProps {
  activeTab: 'register' | 'recognize';
  setActiveTab: (tab: 'register' | 'recognize') => void;
}

const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <header className="bg-slate-800 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center">
            <ScanFace className="w-8 h-8 text-blue-500 mr-2" />
            <h1 className="text-xl font-bold text-slate-100">FaceQA</h1>
          </div>
          
          <nav className="flex space-x-1">
            <button 
              className={`tab ${activeTab === 'register' ? 'tab-active' : ''}`}
              onClick={() => setActiveTab('register')}
            >
              <div className="flex items-center">
                <UserPlus className="w-5 h-5 mr-2" />
                <span>Register</span>
              </div>
            </button>
            
            <button 
              className={`tab ${activeTab === 'recognize' ? 'tab-active' : ''}`}
              onClick={() => setActiveTab('recognize')}
            >
              <div className="flex items-center">
                <ScanFace className="w-5 h-5 mr-2" />
                <span>Recognize</span>
              </div>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Navbar;