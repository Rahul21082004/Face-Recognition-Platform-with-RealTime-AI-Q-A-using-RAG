import React, { createContext, useContext, useState, useEffect } from 'react';
import * as faceapi from 'face-api.js';
import { useSocketContext } from './SocketContext';

interface FaceContextType {
  isModelLoaded: boolean;
  loadingProgress: number;
  detectFaces: (imageData: string) => Promise<any[]>;
  registerFace: (name: string, imageData: string) => Promise<void>;
  recognizeFaces: (imageData: string) => Promise<Array<{
    name: string;
    box: { x: number; y: number; width: number; height: number; };
  }>>;
}

const FaceContext = createContext<FaceContextType | undefined>(undefined);

export const useFaceContext = () => {
  const context = useContext(FaceContext);
  if (context === undefined) {
    throw new Error('useFaceContext must be used within a FaceProvider');
  }
  return context;
};

export const FaceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const { socket } = useSocketContext();

  // Load face-api models on component mount
  useEffect(() => {
    const loadModels = async () => {
      const MODEL_URL = '/models';
      
      try {
        // Create models directory if it doesn't exist
        await Promise.all([
          faceapi.nets.ssdMobilenetv1.load(MODEL_URL)
            .then(() => setLoadingProgress(25)),
          faceapi.nets.faceLandmark68Net.load(MODEL_URL)
            .then(() => setLoadingProgress(50)),
          faceapi.nets.faceRecognitionNet.load(MODEL_URL)
            .then(() => setLoadingProgress(75)),
          faceapi.nets.faceExpressionNet.load(MODEL_URL)
            .then(() => setLoadingProgress(100))
        ]);
        
        setIsModelLoaded(true);
        console.log('Face-API models loaded successfully');
      } catch (error) {
        console.error('Error loading face-api models:', error);
      }
    };

    loadModels();
  }, []);

  // Convert base64 image to HTML Image element
  const createImageFromBase64 = async (base64Image: string): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = base64Image;
    });
  };

  // Detect faces in an image
  const detectFaces = async (imageData: string) => {
    if (!isModelLoaded) {
      throw new Error('Face detection models not loaded yet');
    }

    const img = await createImageFromBase64(imageData);
    const detections = await faceapi
      .detectAllFaces(img)
      .withFaceLandmarks()
      .withFaceDescriptors();
    
    return detections;
  };

  // Register a face with the backend
  const registerFace = async (name: string, imageData: string): Promise<void> => {
    if (!isModelLoaded || !socket) {
      throw new Error('Face detection models not loaded or socket not connected');
    }
    
    const detections = await detectFaces(imageData);
    
    if (detections.length === 0) {
      throw new Error('No face detected in the image');
    }
    
    // Use the first detected face (assuming one face in registration image)
    const faceData = {
      name,
      imageData,
      descriptor: Array.from(detections[0].descriptor),
      timestamp: new Date().toISOString()
    };
    
    return new Promise((resolve, reject) => {
      socket.emit('register-face', faceData, (response: { success: boolean, error?: string }) => {
        if (response.success) {
          resolve();
        } else {
          reject(new Error(response.error || 'Failed to register face'));
        }
      });
    });
  };

  // Recognize faces in an image
  const recognizeFaces = async (imageData: string) => {
    if (!isModelLoaded || !socket) {
      throw new Error('Face detection models not loaded or socket not connected');
    }
    
    const detections = await detectFaces(imageData);
    
    if (detections.length === 0) {
      return [];
    }
    
    // Extract face descriptors
    const descriptors = detections.map(detection => Array.from(detection.descriptor));
    
    // Send descriptors to backend for recognition
    return new Promise((resolve, reject) => {
      socket.emit('recognize-faces', { descriptors }, (response: { 
        success: boolean, 
        faces?: Array<{
          name: string;
          box: { x: number; y: number; width: number; height: number; };
        }>,
        error?: string
      }) => {
        if (response.success && response.faces) {
          // Match recognized faces with detection boxes
          const recognizedFaces = response.faces.map((face, index) => ({
            name: face.name,
            box: detections[index].detection.box
          }));
          resolve(recognizedFaces);
        } else {
          reject(new Error(response.error || 'Failed to recognize faces'));
        }
      });
    });
  };

  return (
    <FaceContext.Provider value={{
      isModelLoaded,
      loadingProgress,
      detectFaces,
      registerFace,
      recognizeFaces
    }}>
      {children}
    </FaceContext.Provider>
  );
};