import React, { useState } from 'react';
import { Brain, Camera, MessageSquare, User, ShieldCheck } from 'lucide-react';
import Navbar from './components/Navbar';
import RegistrationTab from './components/RegistrationTab';
import RecognitionTab from './components/RecognitionTab';
import ChatWidget from './components/ChatWidget';
import { FaceProvider } from './context/FaceContext';
import { SocketProvider } from './context/SocketContext';

function App() {
  const [activeTab, setActiveTab] = useState<'register' | 'recognize'>('register');
  const [isChatOpen, setIsChatOpen] = useState(false);
  
  return (
    <SocketProvider>
      <FaceProvider>
        <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col">
          <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />
          
          <main className="flex-1 container mx-auto px-4 py-8 relative">
            {activeTab === 'register' ? (
              <RegistrationTab />
            ) : (
              <RecognitionTab />
            )}
            
            {/* Features Section */}
            <section className="mt-12 mb-8">
              <h2 className="text-2xl font-bold mb-6 text-center">Platform Features</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="card flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-full bg-blue-900 flex items-center justify-center mb-4">
                    <Camera className="w-6 h-6 text-blue-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Face Recognition</h3>
                  <p className="text-slate-400 text-sm">Advanced real-time recognition of multiple faces simultaneously</p>
                </div>
                
                <div className="card flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-full bg-emerald-900 flex items-center justify-center mb-4">
                    <User className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">User Registration</h3>
                  <p className="text-slate-400 text-sm">Simple and secure face registration with name association</p>
                </div>
                
                <div className="card flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-full bg-purple-900 flex items-center justify-center mb-4">
                    <Brain className="w-6 h-6 text-purple-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">AI-Powered Q&A</h3>
                  <p className="text-slate-400 text-sm">Intelligent responses using RAG technology and OpenAI</p>
                </div>
                
                <div className="card flex flex-col items-center text-center">
                  <div className="w-12 h-12 rounded-full bg-rose-900 flex items-center justify-center mb-4">
                    <ShieldCheck className="w-6 h-6 text-rose-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Secure Storage</h3>
                  <p className="text-slate-400 text-sm">Safe storage of facial data and user information</p>
                </div>
              </div>
            </section>
          </main>

          {/* Chat Button */}
          <div 
            className={`fixed bottom-6 right-6 z-50 ${isChatOpen ? 'hidden' : 'block'}`}
            onClick={() => setIsChatOpen(true)}
          >
            <button className="btn btn-primary rounded-full w-14 h-14 pulse">
              <MessageSquare size={24} />
            </button>
          </div>
          
          {/* Chat Widget */}
          {isChatOpen && <ChatWidget onClose={() => setIsChatOpen(false)} />}
        </div>
      </FaceProvider>
    </SocketProvider>
  );
}

export default App;