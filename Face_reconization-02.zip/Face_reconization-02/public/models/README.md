# Face-API.js Models

This directory will be populated with face-api.js models at runtime. The models will be downloaded from the CDN when the application starts for the first time.

The following models are used by the application:
- SSD Mobilenet V1 (face detection)
- Face Landmark 68 (facial landmark detection)
- Face Recognition (face descriptors/embeddings)
- Face Expression (expression detection)

These files will be fetched from the CDN automatically by face-api.js when the application loads.